<?php
require 'db_conn.php';

if ($conn) {
    $patientQuery = "SELECT healthcare_id, healthcarestaff_name FROM admin_healthcare_unit";
    $patientResult = $conn->query($patientQuery);

    if ($patientResult) {
        if ($patientResult->num_rows > 0) {
            while ($patientRow = $patientResult->fetch_assoc()) {
                echo "<option value='" . $patientRow['healthcare_id'] . "' data-name='" . htmlspecialchars($patientRow['healthcarestaff_name'], ENT_QUOTES, 'UTF-8') . "'>"
                     . $patientRow['healthcare_id'] . " (" . htmlspecialchars($patientRow['healthcarestaff_name'], ENT_QUOTES, 'UTF-8') . ")</option>";
            }
        } else {
            echo "<option disabled>No staff available</option>";
        }
    } else {
        echo "<option disabled>Error loading patients: " . $conn->error . "</option>";
    }
} else {
    echo "<option disabled>Connection error</option>";
}
?>
