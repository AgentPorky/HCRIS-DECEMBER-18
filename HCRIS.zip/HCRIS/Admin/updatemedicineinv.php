<?php
// DATABASE CONNECTION !!
require 'db_conn.php'; // Include your database connection file

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect data from the POST request
    $medicine_id = $_POST['medicine_id'];
    $medicine_name = $_POST['medicine_name'];
    $medicine_quantity = $_POST['medicine_quantity'];
    $date_manufactured = $_POST['date_manufactured'];
    $expiration_date = $_POST['expiration_date'];

    // Validate that all fields are set and not empty
    if (
        !empty($medicine_id) &&
        !empty($medicine_name) &&
        !empty($medicine_quantity) &&
        !empty($date_manufactured) &&
        !empty($expiration_date)
    ) {
        // SQL query to update the medicine details
        $sql = "UPDATE admin_medicine_inventory 
                SET medicine_name = ?, 
                    medicine_quantity = ?, 
                    date_manufactured = ?, 
                    expiration_date = ? 
                WHERE medicine_id = ?";

        $stmt = $conn->prepare($sql);

        if ($stmt) {
            // Bind parameters to the query
            $stmt->bind_param("sisss", $medicine_name, $medicine_quantity, $date_manufactured, $expiration_date, $medicine_id);

            // Execute the query
            if ($stmt->execute()) {
                echo "<script>alert('Medicine record updated successfully'); window.location.href='adminmedicine.php';</script>";
            } else {
                echo "Error updating record: " . $stmt->error;
            }

            $stmt->close();
        } else {
            echo "Error preparing statement: " . $conn->error;
        }
    } else {
        echo "All fields are required.";
    }
} else {
    echo "Invalid request method.";
}

// Close the database connection
$conn->close();
?>
