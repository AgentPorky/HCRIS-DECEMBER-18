<?php
// Start session
session_start();
include "db_conn.php";

// Check if the user is logged in
if (isset($_SESSION['admin_name']) && isset($_SESSION['admin_id'])) {
    // Retrieve admin details from session
    $adminName = $_SESSION['admin_name'];
    $adminId = $_SESSION['admin_id'];

    // Insert logout time into adminlogoutsessions table
    $insertLogout = "INSERT INTO adminlogoutsessions (admin_name, admin_id, logout_time) VALUES (?, ?, NOW())";
    $logoutStmt = $conn->prepare($insertLogout);

    if ($logoutStmt) {
        $logoutStmt->bind_param("ss", $adminName, $adminId);
        $logoutStmt->execute();
    } else {
        // Debugging SQL error (Optional: Enable for troubleshooting)
        error_log("Logout SQL Error: " . $conn->error);
    }
}

// Destroy the session to log out the user
session_unset();
session_destroy();

// Redirect to login page
header("Location: Index.php");
exit();
?>
