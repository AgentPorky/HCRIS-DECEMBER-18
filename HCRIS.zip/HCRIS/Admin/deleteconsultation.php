<?php
require 'db_conn.php'; // Include your database connection script
header('Content-Type: application/json');

// Validate the request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ids']) && is_array($_POST['ids'])) {
    $ids = array_filter($_POST['ids'], 'is_numeric'); // Ensure IDs are numeric

    if (!empty($ids)) {
        // Prepare a parameterized query for deletion
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $sql = "DELETE FROM consultations WHERE consultation_id IN ($placeholders)";
        
        if ($stmt = $conn->prepare($sql)) {
            $stmt->bind_param(str_repeat('i', count($ids)), ...$ids); // Bind parameters
            
            if ($stmt->execute()) {
                echo json_encode(['success' => true, 'message' => 'Selected records have been deleted successfully.']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to delete records.']);
            }
            $stmt->close();
        } else {
            echo json_encode(['success' => false, 'message' => 'Error preparing the SQL statement.']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'No valid IDs provided.']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request.']);
}

$conn->close(); // Close the database connection
?>
