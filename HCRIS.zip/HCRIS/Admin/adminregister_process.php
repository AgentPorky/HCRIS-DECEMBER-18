<?php
session_start();
include "db_conn.php";

if (isset($_POST['admin_id']) && isset($_POST['uname']) && isset($_POST['password']) && isset($_POST['confirm_password']) && isset($_POST['name'])) {
    function validate($data) {
        return htmlspecialchars(stripslashes(trim($data)));
    }

    // Sanitize inputs
    $admin_id = validate($_POST['admin_id']);
    $uname = validate($_POST['uname']);
    $pass = validate($_POST['password']);
    $confirmPass = validate($_POST['confirm_password']);
    $name = validate($_POST['name']);

    // Check for empty fields
    if (empty($admin_id) || empty($uname) || empty($pass) || empty($confirmPass) || empty($name)) {
        header("Location: register.php?error=All fields are required");
        exit();
    }

    // Check if passwords match
    if ($pass !== $confirmPass) {
        header("Location: register.php?error=Passwords do not match");
        exit();
    }

    // Check if admin_id already exists
    $sql = "SELECT * FROM admin_register WHERE admin_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $admin_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        header("Location: register.php?error=Admin ID already exists");
        exit();
    }

    // Check if username already exists
    $sql = "SELECT * FROM admin_register WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $uname);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        header("Location: register.php?error=Username already exists");
        exit();
    }

    // Insert new user into database
    $sql = "INSERT INTO admin_register (admin_id, username, password, name) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssss", $admin_id, $uname, $pass, $name);

    if ($stmt->execute()) {
        // Use JavaScript for the success alert and redirection
        echo "<script>
            alert('Account created successfully! Redirecting to homepage...');
            window.location.href = 'adminhomepage.php';
        </script>";
        exit();
    } else {
        header("Location: register.php?error=Something went wrong. Please try again.");
        exit();
    }
} else {
    header("Location: register.php");
    exit();
}
?>
