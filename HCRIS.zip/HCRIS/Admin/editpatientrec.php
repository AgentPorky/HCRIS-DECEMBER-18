<?php
require '../Admin/db_conn.php';

// Check if patient_id is passed in the URL
if (isset($_GET['id'])) {
    $patient_id = $_GET['id'];
} else {
    // If no patient_id is passed, redirect to the main page
    header('Location: adminpatientrec.php');
    exit();
}

// Fetch the patient record for the given patient_id
$sql = "SELECT * FROM patients WHERE patient_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $patient_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Fetch patient data
    $patient = $result->fetch_assoc();
} else {
    // If no patient is found, redirect
    echo "Patient record not found.";
    exit();
}

// Handle form submission for editing the record
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $fullname = $_POST['fullname'];
    $birthday = $_POST['birthday'];
    $age = $_POST['age'];
    $address = $_POST['address'];
    $socialStatus = $_POST['socialStatus'];
    $gender = $_POST['gender'];
    $username = $_POST['username'];
    $password = $_POST['password'];

    // If password is empty, don't update it
    if (empty($password)) {
        $sql = "UPDATE patients SET fullname = ?, birthday = ?, age = ?, address = ?, Social_stat = ?, gender = ?, username = ? WHERE patient_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssissssi", $fullname, $birthday, $age, $address, $socialStatus, $gender, $username, $patient_id);
    } else {
        // Update the password if provided
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT); // Hash the password
        $sql = "UPDATE patients SET fullname = ?, birthday = ?, age = ?, address = ?, Social_stat = ?, gender = ?, username = ?, password = ? WHERE patient_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssisssssi", $fullname, $birthday, $age, $address, $socialStatus, $gender, $username, $hashedPassword, $patient_id);
    }

    if ($stmt->execute()) {
        // Redirect back to patient records page with success message
        header("Location: adminpatientrec.php?message=updated");
        exit();
    } else {
        echo "Error updating record: " . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Patient Record</title>
    <!-- Include Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h3>Edit Patient Record</h3>
        <form action="editpatientrec.php?id=<?php echo $patient_id; ?>" method="POST">
            <div class="mb-3">
                <label for="fullname" class="form-label">Patient Name</label>
                <input type="text" class="form-control" id="fullname" name="fullname" value="<?php echo $patient['fullname']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="birthday" class="form-label">Birthdate</label>
                <input type="date" class="form-control" id="birthday" name="birthday" value="<?php echo $patient['birthday']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="age" class="form-label">Age</label>
                <input type="number" class="form-control" id="age" name="age" value="<?php echo $patient['age']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="address" class="form-label">Address</label>
                <input type="text" class="form-control" id="address" name="address" value="<?php echo $patient['address']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="socialStatus" class="form-label">Social Status</label>
                <select class="form-control" id="socialStatus" name="socialStatus" required>
                    <option value="single" <?php echo ($patient['Social_stat'] == 'single') ? 'selected' : ''; ?>>Single</option>
                    <option value="married" <?php echo ($patient['Social_stat'] == 'married') ? 'selected' : ''; ?>>Married</option>
                    <option value="widowed" <?php echo ($patient['Social_stat'] == 'widowed') ? 'selected' : ''; ?>>Widowed</option>
                    <option value="divorced" <?php echo ($patient['Social_stat'] == 'divorced') ? 'selected' : ''; ?>>Divorced</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="gender" class="form-label">Gender</label>
                <select class="form-control" id="gender" name="gender" required>
                    <option value="male" <?php echo ($patient['gender'] == 'male') ? 'selected' : ''; ?>>Male</option>
                    <option value="female" <?php echo ($patient['gender'] == 'female') ? 'selected' : ''; ?>>Female</option>
                    <option value="other" <?php echo ($patient['gender'] == 'other') ? 'selected' : ''; ?>>Other</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="username" class="form-label">Username</label>
                <input type="text" class="form-control" id="username" name="username" value="<?php echo $patient['username']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" class="form-control" id="password" name="password" placeholder="Leave empty if you don't want to change">
            </div>
            <button type="submit" class="btn btn-primary">Update Record</button>
            <a href="adminpatientrec.php" class="btn btn-secondary">Cancel</a>
        </form>
    </div>
    
    <!-- Include Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
