<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../Css/adminhomepagestyles.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <title>Admin Login and Logout Sessions</title>
   
</head>
<body>
    <!-- Sidebar for navigation links -->
    <aside>
        <div id="sidenav" class="col-2">
            <ul class="nav nav-pills flex-column mb-auto">
                <li class="nav-item">
                    <a href="adminhomepage.php" class="nav-link">
                        <i class="fa-solid fa-hospital me-2"></i>
                        <span class="d-none d-sm-inline text-white">DASHBOARD</span>
                    </a>
                </li>
                <hr>
                <li class="nav-item">
                    <a href="adminconsultation.php" class="nav-link">
                        <i class="fa-solid fa-stethoscope me-2"></i>
                        <span class="d-none d-sm-inline text-white">Consultation</span>
                    </a>
                </li>
                <hr>
                <li class="nav-item">
                    <a href="Appointments.php" class="nav-link">
                        <i class="fa-solid fa-users me-2"></i>
                        <span class="d-none d-sm-inline text-white">Appointments</span>
                    </a>
                </li>
                <hr>
                <li class="nav-item">
                    <a href="adminmedicine.php" class="nav-link">
                        <i class="fa-solid fa-pills me-2"></i>
                        <span class="d-none d-sm-inline text-white">Medicine Inventory</span>
                    </a>
                </li>
                <hr>
                <li class="nav-item">
                    <a href="healthcare_staff.php" class="nav-link">
                        <i class="fa-solid fa-user-nurse me-2"></i>
                        <span class="d-none d-sm-inline text-white">Healthcare Staff</span>
                    </a>
                </li>
                <hr>
                <li class="nav-item">
                    <a href="adminpatientrec.php" class="nav-link">
                        <i class="fa-solid fa-user me-2"></i>
                        <span class="d-none d-sm-inline text-white">Patient Record</span>
                    </a>
                </li>
                <hr>
                <li class="nav-item">
                    <a href="adminreport.php" class="nav-link">
                        <i class="fa-solid fa-chart-line me-2"></i>
                        <span class="d-none d-sm-inline text-white">Report</span>
                    </a>
                </li>
                <hr>
                <li class="nav-item">
                    <a href="adminloginsessions.php" class="nav-link">
                        <i class="fa-solid fa-history me-2"></i>
                        <span class="d-none d-sm-inline text-white">Activity Log</span>
                    </a>
                </li>
                <hr>
                <li class="nav-item">
                    <a id="signOutBtn" class="nav-link">
                        <i class="fa-solid fa-sign-out-alt me-2"></i>
                        <span class="d-none d-sm-inline text-white">Log Out</span>
                    </a>
                </li>
            </ul>
        </div>
    </aside>



    <!-- HEADER NAV BAR -->
    <header>
    <nav class="navbar navbar-expand-sm">
        <div class="logo-text-container">
            <div class="d-flex align-items-center">
                <img src="../Photos/logo.png" alt="Healthcare Logo" class="logo">
                <p class="logo-text text-white h3">Panghiawan Barangay Healthcare</p>
            </div>
            <p class="logo-text text-white h3 text-end">Welcome admin!</p>
        </div>
    </nav>
</header>
    <!-- MAIN CONTENT -->
    <main>
        <div class="table-container table-responsive">
            <?php
            require 'db_conn.php';

            if (!$conn) {
                die("<div class='alert alert-danger'>Connection failed: " . mysqli_connect_error() . "</div>");
            }

            // Fetch login data
            $loginQuery = "SELECT log_id, admin_name, admin_id, login_time FROM admin_loginsessions";
            $loginResult = $conn->query($loginQuery);

            if ($loginResult->num_rows > 0) {
                echo "<table id='loginSessionTable' class='display table table-bordered table-hover'>
                        <thead>
                            <tr>
                                <th>Log ID</th>
                                <th>Admin Name</th>
                                <th>Admin ID</th>
                                <th>Login Time</th>
                            </tr>
                        </thead>
                        <tbody>";

                while ($row = $loginResult->fetch_assoc()) {
                    echo "<tr>
                            <td>{$row['log_id']}</td>
                            <td>{$row['admin_name']}</td>
                            <td>{$row['admin_id']}</td>
                            <td>{$row['login_time']}</td>
                          </tr>";
                }

                echo "</tbody></table>";
            } else {
                echo "<div class='alert alert-warning'>No login records found.</div>";
            }

            // Fetch logout data
            $logoutQuery = "SELECT logout_id, admin_name, admin_id, logout_time FROM adminlogoutsessions";
            $logoutResult = $conn->query($logoutQuery);

            if ($logoutResult->num_rows > 0) {
                echo "<table id='logoutSessionTable' class='display table table-bordered table-hover'>
                        <thead>
                            <tr>
                                <th>Logout ID</th>
                                <th>Admin Name</th>
                                <th>Admin ID</th>
                                <th>Logout Time</th>
                            </tr>
                        </thead>
                        <tbody>";

                while ($row = $logoutResult->fetch_assoc()) {
                    echo "<tr>
                            <td>{$row['logout_id']}</td>
                            <td>{$row['admin_name']}</td>
                            <td>{$row['admin_id']}</td>
                            <td>{$row['logout_time']}</td>
                          </tr>";
                }

                echo "</tbody></table>";
            } else {
                echo "<div class='alert alert-warning'>No logout records found.</div>";
            }

            $conn->close();
            ?>
        </div>
    </main>

    <!-- Initialize DataTable -->
    <script>
    $(document).ready(function () {
        // Initialize DataTables for login table
        $('#loginSessionTable').DataTable({
            "paging": true,
            "pageLength": 4,
            "searching": true,
            "ordering": true,
            "lengthMenu": [1, 2, 3, 4] // Restrict entries dropdown to 1-5
        });

        // Initialize DataTables for logout table
        $('#logoutSessionTable').DataTable({
            "paging": true,
            "pageLength": 4,
            "searching": true,
            "ordering": true,
            "lengthMenu": [1, 2, 3, 4] // Restrict entries dropdown to 1-5
        });

        // Logout button confirmation
        $('#signOutBtn').on('click', function (e) {
            e.preventDefault();
            Swal.fire({
                title: 'Are you sure?',
                text: "Do you want to log out?",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes, log out',
                cancelButtonText: 'No, stay here'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = 'logout.php';
                }
            });
        });
    });
</script>

   
</body>
</html>
