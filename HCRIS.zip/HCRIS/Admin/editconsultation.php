<?php
include "db_conn.php"; // Database connection

// Check for ID in URL
if (isset($_GET['id'])) {
    $consultationId = filter_var($_GET['id'], FILTER_SANITIZE_NUMBER_INT);

    // Fetch consultation details
    $sql = "SELECT * FROM consultations WHERE consultation_id = ?";
    $stmt = $conn->prepare($sql);

    if ($stmt) {
        $stmt->bind_param("i", $consultationId);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
        } else {
            echo "<div class='alert alert-danger'>No record found for Consultation ID: $consultationId</div>";
            exit();
        }
    } else {
        echo "<div class='alert alert-danger'>Error: " . $conn->error . "</div>";
        exit();
    }
} else {
    echo "<div class='alert alert-warning'>Consultation ID not found in URL!</div>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Consultation</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <div class="shadow p-4 bg-light rounded">
        <h2 class="text-center mb-4">Edit Consultation</h2>
        <form action="updateconsultation.php" method="POST">
            <!-- Hidden consultation_id -->
    <input type="hidden" name="consultation_id" value="<?php echo isset($row['consultation_id']) ? htmlspecialchars($row['consultation_id']) : ''; ?>">


            <!-- Fullname -->
            <div class="mb-3">
                <label for="fullname" class="form-label">Fullname</label>
                <input type="text" class="form-control" id="fullname" name="fullname" 
                    value="<?php echo isset($row['fullname']) ? htmlspecialchars($row['fullname']) : ''; ?>" required>
            </div>

            <!-- Purpose -->
            <div class="mb-3">
                <label for="purpose" class="form-label">Purpose</label>
                <input type="text" class="form-control" id="purpose" name="purpose" 
                    value="<?php echo isset($row['consultation_purpose']) ? htmlspecialchars($row['consultation_purpose']) : ''; ?>" required>
            </div>

            <!-- Reason -->
            <div class="mb-3">
                <label for="reason" class="form-label">Reason</label>
                <input type="text" class="form-control" id="reason" name="reason" 
                    value="<?php echo isset($row['consultation_reason']) ? htmlspecialchars($row['consultation_reason']) : ''; ?>" required>
            </div>

            <!-- Type of Illness -->
            <div class="mb-3">
                <label for="type_of_illness" class="form-label">Type of Illness</label>
                <input type="text" class="form-control" id="type_of_illness" name="type_of_illness" 
                    value="<?php echo isset($row['type_of_illness']) ? htmlspecialchars($row['type_of_illness']) : ''; ?>" required>
            </div>

            <!-- Disease -->
            <div class="mb-3">
                <label for="disease" class="form-label">Disease</label>
                <input type="text" class="form-control" id="disease" name="disease" 
                    value="<?php echo isset($row['consultation_disease']) ? htmlspecialchars($row['consultation_disease']) : ''; ?>" required>
            </div>

            <!-- Schedule -->
            <div class="mb-3">
                <label for="schedule" class="form-label">Schedule</label>
                <input type="datetime-local" class="form-control" id="schedule" name="schedule" 
                    value="<?php echo isset($row['consultation_schedule']) ? htmlspecialchars($row['consultation_schedule']) : ''; ?>" required>
            </div>

            <!-- Action Buttons -->
            <div class="d-flex justify-content-between">
                <button type="submit" class="btn btn-primary">Update</button>
                <a href="adminconsultation.php" class="btn btn-warning">Cancel</a>
            </div>

        </form>
    </div>
</div>
</body>
</html>
