<?php
require 'db_conn.php';

// Display all errors for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $consultationId = isset($_POST['consultation_id']) ? $_POST['consultation_id'] : null;
    $fullname = isset($_POST['fullname']) ? trim($_POST['fullname']) : null;
    $purpose = isset($_POST['purpose']) ? trim($_POST['purpose']) : null;
    $reason = isset($_POST['reason']) ? trim($_POST['reason']) : null;
    $type_of_illness = isset($_POST['type_of_illness']) ? trim($_POST['type_of_illness']) : null;
    $disease = isset($_POST['disease']) ? trim($_POST['disease']) : null;
    $schedule = isset($_POST['schedule']) ? $_POST['schedule'] : null;

    // Ensure consultation_id is provided
    if (!$consultationId) {
        echo "<script>alert('Error: Consultation ID is missing.'); window.location.href='adminconsultation.php';</script>";
        exit();
    }

    // Validate required fields
    if (empty($fullname) || empty($purpose) || empty($reason) || empty($type_of_illness) || empty($disease) || empty($schedule)) {
        echo "<script>alert('Error: All fields are required.'); window.history.back();</script>";
        exit();
    }

    // Prepare the SQL query to update the consultation details
    $sql = "UPDATE consultations 
            SET fullname = ?, 
                consultation_purpose = ?, 
                consultation_reason = ?, 
                type_of_illness = ?, 
                consultation_disease = ?, 
                consultation_schedule = ?
            WHERE consultation_id = ?";
    
    $stmt = $conn->prepare($sql);

    if ($stmt) {
        // Bind parameters
        $stmt->bind_param("ssssssi", $fullname, $purpose, $reason, $type_of_illness, $disease, $schedule, $consultationId);

        // Execute the query
        if ($stmt->execute()) {
            // Success message and redirect to adminconsultation.php
            echo "<script>
                    alert('Consultation updated successfully!');
                    window.location.href='adminconsultation.php';
                  </script>";
            exit();
        } else {
            // If execution fails
            echo "<script>alert('Error updating record: " . $stmt->error . "'); window.history.back();</script>";
        }

        $stmt->close();
    } else {
        // SQL preparation error
        echo "<script>alert('Database preparation error: " . $conn->error . "'); window.history.back();</script>";
    }
} else {
    // Invalid request method
    echo "<script>alert('Invalid request method.'); window.location.href='adminconsultation.php';</script>";
}

$conn->close();
?>
