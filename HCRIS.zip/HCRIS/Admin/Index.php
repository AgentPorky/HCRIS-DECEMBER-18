<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <!-- External CSS -->
    <link rel="stylesheet" type="text/css" href="../Css/styles.css">
</head>
<body>
    <div class="login-container">
        <!-- Login Form -->
        <form action="login.php" method="post">
            <h2>Admin Login</h2>

            <!-- Display error messages -->
            <?php if (isset($_GET['error'])): ?>
                <p class="error"><?php echo htmlspecialchars($_GET['error']); ?></p>
            <?php endif; ?>

            <!-- Username Input -->
            <div class="input-box">
                <label for="uname">Username</label>
                <input type="text" name="uname" id="uname" placeholder="Enter Username" required>
            </div>

            <!-- Password Input -->
            <div class="input-box">
                <label for="password">Password</label>
                <input type="password" name="password" id="password" placeholder="Enter Password" required>
            </div>

            <!-- Submit Button -->
            <button type="submit" class="login-btn">Login</button>
        </form>
    </div>
</body>
</html>
