<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap CSS for styling -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome for icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" rel="stylesheet">
    
    <!-- Bootstrap JavaScript bundle for modal and other components -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- BUILT IN STYLE OF THE TABLE -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <!-- SheetJS Library for Excel Export -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>

    <!-- jsPDF Library for PDF Export -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>

    <!-- jsPDF AutoTable Plugin -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.25/jspdf.plugin.autotable.min.js"></script>
    <!-- Custom CSS file for additional styles -->
    <link rel="stylesheet" href="../Css/patientrecordstyles.css">

    <title>ADMIN_PATIENT_RECORD</title>
</head>
<body>
    <!-- Sidebar for navigation links -->
    <aside>
        <div id="sidenav" class="col-2">
            <ul class="nav nav-pills flex-column mb-auto">
                <!-- Navigation Links -->
                <li class="nav-item">
                    <a href="adminhomepage.php" class="nav-link">
                        <i class="fa-solid fa-hospital me-2"></i>
                        <span class="d-none d-sm-inline text-white">DASHBOARD</span>
                    </a>
                </li>
                <hr>
                <li class="nav-item">
                    <a href="adminconsultation.php" class="nav-link">
                        <i class="fa-solid fa-stethoscope me-2"></i>
                        <span class="d-none d-sm-inline text-white">Consultation</span>
                    </a>
                </li>
                <hr>
                <li class="nav-item">
                    <a href="Appointments.php" class="nav-link">
                        <i class="fa-solid fa-users me-2"></i>
                        <span class="d-none d-sm-inline text-white">Appointments</span>
                    </a>
                </li>
                <hr>
                <li class="nav-item">
                    <a href="adminmedicine.php" class="nav-link">
                        <i class="fa-solid fa-pills me-2"></i>
                        <span class="d-none d-sm-inline text-white">Medicine Inventory</span>
                    </a>
                </li>
                <hr>
                <li class="nav-item">
                    <a href="healthcare_staff.php" class="nav-link">
                        <i class="fa-solid fa-user-nurse me-2"></i>
                        <span class="d-none d-sm-inline text-white">Healthcare Staff</span>
                    </a>
                </li>
                <hr>
                <li class="nav-item">
                    <a href="adminpatientrec.php" class="nav-link">
                        <i class="fa-solid fa-user me-2"></i>
                        <span class="d-none d-sm-inline text-white">Patient Record</span>
                    </a>
                </li>
                <hr>
                <li class="nav-item">
                    <a href="adminreport.php" class="nav-link">
                        <i class="fa-solid fa-chart-line me-2"></i>
                        <span class="d-none d-sm-inline text-white">Report</span>
                    </a>
                 <hr>
                </li>
                <li class="nav-item">
                    <a href="adminloginsessions.php" class="nav-link">
                        <i class="fa-solid fa-history me-2"></i>
                        <span class="d-none d-sm-inline text-white">Activity Log</span>
                    </a>
                </li>
                <hr>
                <li class="nav-item">
                    <a id="signOutBtn" class="nav-link">
                        <i class="fa-solid fa-sign-out-alt me-2"></i>
                        <span class="d-none d-sm-inline text-white">Log Out</span>
                    </a>
                </li>

            </ul>
        </div>
    </aside>

    <!-- Header Navigation Bar -->
    <header>
        <nav class="navbar navbar-expand-sm">
            <div class="logo-text-container">
                <img src="../Photos/logo.png" alt="Healthcare Logo" class="logo">
                <p class="logo-text text-white h3">Panghiawan Barangay Healthcare</p>
            </div>
        </nav>
    </header>
   
    <main>
        <div class="container col-10 bg-light">
            <button id="delete-selected" class="btn btn-danger mx-5">Delete Selected</button>
            <button id="export-excel" class="btn btn-success mx-2">Download As Excel</button>
            <button id="export-pdf" class="btn btn-success mx-2">Download As PDF</button>
        </div>
            
            <!-- Responsive Table List -->
    
            <?php
            require '../Admin/db_conn.php';
            // Check connection
            if (!$conn) {
                echo "Connection failed!";
                exit();
            }

            // Query to select data from the table
            $sql = "SELECT * FROM patients";
            $result = $conn->query($sql);
            ?>

            <?php
            // Check if there are results and display them
            if ($result->num_rows > 0) {
                echo "<table id='patientTable' class='display table table-striped table-hover table-bordered mx-auto' style='width: 80%;'>
                        <thead class='bg-success'>
                            <tr>
                                <th>Select</th>
                                <th>Patient ID</th>
                                <th>Full Name</th>
                                <th>Birthdate</th>
                                <th>Age</th>
                                <th>Address</th>
                                <th>Social Status</th>
                                <th>Gender</th>
                                <th>Username</th>
                                <th>OTP's</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>";
            
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td><input type='checkbox' class='row-checkbox'></td>
                            <td>" . $row['patient_id'] . "</td>
                            <td>" . $row['fullname'] . "</td>
                            <td>" . $row['birthday'] . "</td>
                            <td>" . $row['age'] . "</td>
                            <td>" . $row['address'] . "</td>
                            <td>" . $row['Social_stat'] . "</td>
                            <td>" . $row['gender'] . "</td>
                            <td>" . $row['username'] . "</td>
                            <td>" . $row['otps'] . "</td>
                            <td class='btn-container'>
                                <div class='d-flex justify-content-between'>
                                    <button class='btn btn-success btn-sm me-2' onclick=\"window.location.href='editpatientrec.php?id=" . $row['patient_id'] . "'\">
                                        Edit
                                    </button>
                                </div>
                            </td>
                        </tr>";
                }
                echo "</tbody></table>";
            } else {
                echo "<div class='alert alert-warning'>No records found.</div>";
            }

            // Close the database connection
            $conn->close();
            ?>
    </main>

    <!-- SCRIPT OF THE TABLE BELOW -->
    <script>

    // Bulk deletion handling
    $('#delete-selected').click(function() {
        const selectedIds = [];
        // Collect all selected checkboxes' patient IDs
        $('input.row-checkbox:checked').each(function() {
            selectedIds.push($(this).closest('tr').find('td').eq(1).text()); // Get patient_id from the second column
        });

        if (selectedIds.length > 0) {
            Swal.fire({
                title: 'Are you sure?',
                text: "Do you really want to delete the selected patient records?",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes, delete!',
                cancelButtonText: 'No, cancel'
            }).then((result) => {
                if (result.isConfirmed) {
                    // AJAX request for bulk deletion
                    $.ajax({
                        url: 'deletepatientrec.php',
                        type: 'POST',
                        data: { ids: selectedIds },
                        success: function(response) {
                            Swal.fire(
                                'Deleted!',
                                'The selected patient records have been deleted.',
                                'success'
                            );
                            location.reload(); // Refresh the page
                        },
                        error: function() {
                            Swal.fire(
                                'Error!',
                                'There was an error deleting the records.',
                                'error'
                            );
                        }
                    });
                }
            });
        } else {
            Swal.fire(
                'No selection!',
                'Please select at least one patient record to delete.',
                'info'
            );
        }
    });


        $(document).ready(function() {
            $('#patientTable').DataTable({
                "paging": true,
                "searching": true,
                "ordering": true,
                "pageLength": 10,
                "lengthMenu": [5, 10, 25, 50]
            });
        });
        document.addEventListener('DOMContentLoaded', function () {
        // Ensure the DOM is fully loaded before running the script
        const logoutButton = document.querySelector('#signOutBtn');
        if (logoutButton) {
            logoutButton.addEventListener('click', function (e) {
                e.preventDefault(); // Prevent the default link action
                Swal.fire({
                    title: 'Are you sure?',
                    text: "Do you really want to sign out?",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, sign out!',
                    cancelButtonText: 'No, stay logged in'
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.location.href = 'logout.php'; // Adjust the URL to your logout script
                    }
                });
            });
        } else {
            console.error("Logout button (signOutBtn) not found!");
        }
    });
    const togglePassword = document.getElementById('togglePassword');
    const passwordInput = document.getElementById('password');

    togglePassword.addEventListener('click', () => {
        const type = passwordInput.type === 'password' ? 'text' : 'password';
        passwordInput.type = type;

        // Change the button text/icon
        togglePassword.textContent = type === 'password' ? '👁️' : '🙈';
    });

     // SCRIPT FOR DOWNLOAD AS EXCEL AND PDF
     $(document).ready(function() {
    $('#patientTable').DataTable();

    $('#export-excel').click(function() {
        const table = document.getElementById('patientTable');
        const workbook = XLSX.utils.table_to_book(table, { sheet: "Sheet1" });
        XLSX.writeFile(workbook, 'patientRecord_Data.xlsx');
    });

    $('#export-pdf').click(function() {
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();
        doc.autoTable({
            html: '#patientTable',
        });
        doc.save('patientRecord_Data.pdf');
    });
});


    </script>

</body>
</html>
