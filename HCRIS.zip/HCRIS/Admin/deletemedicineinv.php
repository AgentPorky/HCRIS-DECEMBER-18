<?php
require 'db_conn.php';

// Check the database connection
if (!$conn) {
    die(json_encode(['success' => false, 'error' => 'Database connection failed']));
}

// Decode the incoming JSON data
$data = json_decode(file_get_contents('php://input'), true);

// Check if 'medicine_ids' is provided
if (!isset($data['medicine_ids']) || empty($data['medicine_ids'])) {
    echo json_encode(['success' => false, 'error' => 'No IDs provided']);
    exit;
}

$medicine_ids = $data['medicine_ids'];

// Sanitize and prepare the query for multiple deletions
$placeholders = implode(',', array_fill(0, count($medicine_ids), '?'));
$query = "DELETE FROM admin_medicine_inventory WHERE medicine_id IN ($placeholders)";
$stmt = $conn->prepare($query);

if (!$stmt) {
    echo json_encode(['success' => false, 'error' => 'Failed to prepare query: ' . $conn->error]);
    exit;
}

// Bind the parameters dynamically (assuming medicine_ids are strings now)
$stmt->bind_param(str_repeat('s', count($medicine_ids)), ...$medicine_ids);

// Execute the query and check for success
if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Selected records deleted successfully']);
} else {
    echo json_encode(['success' => false, 'error' => 'Failed to delete records: ' . $stmt->error]);
}

// Close the statement and connection
$stmt->close();
$conn->close();
?>
