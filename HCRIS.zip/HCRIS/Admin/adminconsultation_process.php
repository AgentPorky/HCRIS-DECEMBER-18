<?php
require 'db_conn.php';

// Enable detailed error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Debug: Log POST data
    error_log("POST DATA: " . print_r($_POST, true));

    // Fetch form data
    $healthcare_id = isset($_POST['healthcare_id']) ? $_POST['healthcare_id'] : null;
    $patient_id = isset($_POST['patient_id']) ? $_POST['patient_id'] : null;
    $patient_name = isset($_POST['patient_name']) ? $_POST['patient_name'] : null;
    $purpose = isset($_POST['purpose']) ? $_POST['purpose'] : null;
    $reason = isset($_POST['reason']) ? $_POST['reason'] : null;
    $type_of_illness = isset($_POST['type_of_illness']) ? $_POST['type_of_illness'] : null;
    $disease = isset($_POST['disease']) ? $_POST['disease'] : null;
    $medicine_id = isset($_POST['medicine_id']) ? $_POST['medicine_id'] : null;
    $quantity = isset($_POST['quantity']) ? $_POST['quantity'] : null;
    $recommendation = isset($_POST['recommendation']) ? $_POST['recommendation'] : 'N/A';
    $schedule = isset($_POST['schedule']) ? $_POST['schedule'] : null;

    // Validation
    if (
        empty($healthcare_id) || empty($patient_id) || empty($patient_name) || 
        empty($purpose) || empty($reason) || empty($type_of_illness) || 
        empty($disease) || empty($medicine_id) || empty($quantity) || empty($schedule)
    ) {
        die("Error: All fields are required.");
    }

    // Start a transaction
    $conn->begin_transaction();
    try {
        // Fetch medicine details
        $stmtMedicine = $conn->prepare("SELECT medicine_name, medicine_quantity FROM admin_medicine_inventory WHERE medicine_id = ?");
        $stmtMedicine->bind_param("s", $medicine_id);
        $stmtMedicine->execute();
        $resultMedicine = $stmtMedicine->get_result();

        if ($row = $resultMedicine->fetch_assoc()) {
            $medicine_name = $row['medicine_name'];
            $current_quantity = $row['medicine_quantity'];

            if ($current_quantity < $quantity) {
                // If insufficient medicine, prompt an alert and redirect
                echo "<script>
                    alert('Insufficient medicine quantity for \"$medicine_name\". Please restock.');
                    window.location.href = 'adminmedicine.php';
                </script>";
                $conn->rollback(); // Rollback the transaction
                exit();
            }

            // Update inventory
            $stmtUpdate = $conn->prepare("UPDATE admin_medicine_inventory SET medicine_quantity = medicine_quantity - ? WHERE medicine_id = ?");
            $stmtUpdate->bind_param("is", $quantity, $medicine_id);
            $stmtUpdate->execute();

            // Insert consultation record
            $stmtInsert = $conn->prepare("INSERT INTO consultations 
            (healthcare_id, patient_id, patient_name, purpose, reason, type_of_illness, 
            disease, medicine_name, quantity, recommendation, schedule, status) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Active')");

            if (!$stmtInsert) {
                throw new Exception("Prepare Error: " . $conn->error);
            }

            // Bind parameters
            $stmtInsert->bind_param(
                "ssssssssiss", 
                $healthcare_id, $patient_id, $patient_name, $purpose, $reason, 
                $type_of_illness, $disease, $medicine_name, $quantity, $recommendation, $schedule
            );

            // Execute the query
            if (!$stmtInsert->execute()) {
                throw new Exception("Insert Error: " . $stmtInsert->error);
            }

            $conn->commit(); // Commit the transaction
            echo "<script>
                alert('Consultation record saved successfully.');
                window.location.href = 'adminconsultation.php';
            </script>";
        } else {
            throw new Exception("Medicine not found in inventory.");
        }
    } catch (Exception $e) {
        $conn->rollback();
        error_log("Transaction Failed: " . $e->getMessage());
        echo "<script>
            alert('Error: " . addslashes($e->getMessage()) . "');
            window.location.href = 'adminconsultation.php';
        </script>";
    }

    // Close statements
    $stmtMedicine->close();
    $stmtUpdate->close();
    $stmtInsert->close();
    $conn->close();
} else {
    die("Error: Invalid request method.");
}
?>
