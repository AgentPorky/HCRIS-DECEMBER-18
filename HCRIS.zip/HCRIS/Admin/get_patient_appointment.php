<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include the database connection file
require 'db_conn.php';

// SQL query to fetch data from the `patients_appointment` table
$query = "
    SELECT 
        `appointment_id`, 
        `patient_id`, 
        `patient_name`, 
        `schedule`, 
        `purpose`, 
        `reason`, 
        `t_o_i`, 
        `disease`, 
        `medicine_id`
    FROM `patients_appointment`
";

// Execute the query
$result = $conn->query($query);

// Check if the query was successful
if ($result === false) {
    // If query fails, show the error message
    echo json_encode(["error" => "Query failed: " . $conn->error]);
    exit();
}

// Check if there are rows returned
if ($result->num_rows > 0) {
    // Initialize an array to store the data
    $data = [];
    
    // Fetch each row and store it in the $data array
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }

    // Return the data as a JSON response
    echo json_encode($data);
} else {
    // If no records are found, return a message or an empty array
    echo json_encode(["message" => "No records found."]);
}

// Close the database connection
$conn->close();
?>
