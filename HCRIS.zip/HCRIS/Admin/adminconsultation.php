<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ADMIN_CONSULTATION</title>

    <!-- Bootstrap CSS for styling -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome for icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" rel="stylesheet">
    
    <!-- Select2 CSS for searchable dropdowns -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.1.0-beta.1/css/select2.min.css" rel="stylesheet" />
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.1.0-beta.1/js/select2.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
    <!-- SheetJS Library for Excel Export -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>

    <!-- jsPDF Library for PDF Export -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>

    <!-- jsPDF AutoTable Plugin -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.25/jspdf.plugin.autotable.min.js"></script>

    <!-- DataTables CSS for table styling -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
    <script src="../Javascript/get_patient.js"></script>
    <script src="../Javascript/get_id.js"></script>

    <!-- Custom CSS -->
    <link rel="stylesheet" href="../css/adminconsultationstyles.css">
</head>
<body class="body">

    <!-- Header Navigation Bar -->
    <header>
        <nav class="navbar navbar-expand-sm">
            <div class="logo-text-container">
                <div class="d-flex align-items-center">
                    <img src="../Photos/logo.png" alt="Healthcare Logo" class="logo">
                    <p class="logo-text text-white h3">Panghiawan Barangay Healthcare</p>
                </div>
            </div>
        </nav>
    </header>

    <!-- SIDE BAR -->
    <aside>
        <div id="sidenav" class="col-2">
            <ul class="nav nav-pills flex-column mb-auto">
                <li class="nav-item">
                    <a href="adminhomepage.php" class="nav-link">
                        <i class="fa-solid fa-hospital me-2"></i>
                        <span class="d-none d-sm-inline text-white">DASHBOARD</span>
                    </a>
                </li >
                <hr>
                <li class="nav-item">
                    <a href="adminconsultation.php" class="nav-link">
                        <i class="fa-solid fa-stethoscope me-2"></i>
                        <span class="d-none d-sm-inline text-white">Consultation</span>
                    </a>
                </li>
                <hr>
                <li class="nav-item">
                    <a href="Appointments.php" class="nav-link">
                        <i class="fa-solid fa-users me-2"></i>
                        <span class="d-none d-sm-inline text-white">Appointments</span>
                    </a>
                </li>
                <hr>
                <li class="nav-item">
                    <a href="adminmedicine.php" class="nav-link">
                        <i class="fa-solid fa-pills me-2"></i>
                        <span class="d-none d-sm-inline text-white">Medicine Inventory</span>
                    </a>
                </li>
                <hr>
                <li class="nav-item">
                    <a href="healthcare_staff.php" class="nav-link">
                        <i class="fa-solid fa-user-nurse me-2"></i>
                        <span class="d-none d-sm-inline text-white">Healthcare Staff</span>
                    </a>
                </li>
                <hr>
                <li class="nav-item">
                    <a href="adminpatientrec.php" class="nav-link">
                        <i class="fa-solid fa-user me-2"></i>
                        <span class="d-none d-sm-inline text-white"> Patient Record</span>
                    </a>
                </li>
                <hr>
                <li class="nav-item">
                    <a href="adminreport.php" class="nav-link">
                        <i class="fa-solid fa-chart-line me-2"></i>
                        <span class="d-none d-sm-inline text-white">Report</span>
                    </a>
                </li>
                <hr>
                <li class="nav-item">
                    <a href="adminloginsessions.php" class="nav-link">
                        <i class="fa-solid fa-history me-2"></i>
                        <span class="d-none d-sm-inline text-white">Activity Log</span>
                    </a>
                </li>
                <hr>
                <li class="nav-item">
                    <a id="signOutBtn" class="nav-link">
                        <i class="fa-solid fa-sign-out-alt me-2"></i>
                        <span class="d-none d-sm-inline text-white">Log Out</span>
                    </a>
                </li>
            </ul>
        </div>
    </aside>

    <!-- Add Consultation Modal -->
    <div class="modal fade" id="addConsultationModal" tabindex="-1" aria-labelledby="addConsultationModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addConsultationModalLabel">Add Consultation Here</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="consultationForm" method="post" action="adminconsultation_process.php">
                        <!-- Healthcare staff Selection -->
                        <div class="mb-3">
                            <label for="healthcare_id" class="form-label">Select staff:</label>
                            <select id="healthcare_id" name="healthcare_id" required>
                                <option value="" disabled selected>Select staff</option>
                                <?php include 'get_healthcare_staff.php'; ?>
                            </select>
                        </div>
                        <!-- Patient ID -->
                        <div class="mb-3">
                            <label for="patient_id" class="form-label">Patient_ID:</label>
                            <input type="text" class="form-control" id="patient_id" name="patient_id" placeholder="Enter Patient ID" required readonly>
                        </div>
                        </div>
                        <!-- Patient Selection -->
                        <div class="mb-3">
                            <label for="patient_name" class="form-label">Select Patient:</label>
                            <select id="patient_name" name="patient_name" required>
                                <option value="" disabled selected>Select Patient</option>
                                <?php include 'get_patient_data.php'; ?>
                            </select>
                        </div>


                        <!-- Purpose -->
                        <div class="mb-3">
                            <label for="purpose" class="form-label">Purpose:</label>
                            <input type="text" class="form-control" id="purpose" name="purpose" placeholder="Enter Purpose" required>
                        </div>

                        <!-- Reason -->
                        <div class="mb-3">
                            <label for="reason" class="form-label">Reason:</label>
                            <input type="text" class="form-control" id="reason" name="reason" placeholder="Enter Reason" required>
                        </div>

                        <!-- Type of Illness -->
                        <div class="mb-3">
                            <label for="type_of_illness" class="form-label">Type of Illness:</label>
                            <input type="text" class="form-control" id="type_of_illness" name="type_of_illness" placeholder="Enter Type of Illness (or N/A if none)" required>
                        </div>

                        <!-- Disease -->
                        <div class="mb-3">
                            <label for="disease" class="form-label">Disease:</label>
                            <input type="text" class="form-control" id="disease" name="disease" placeholder="Enter Disease (or N/A if none)" required>
                        </div>

                        <!-- Medicine Selection -->
                        <div class="mb-3">
                            <label for="medicine_id" class="form-label">Select Medicine:</label>
                            <select id="medicine_id" name="medicine_id" required>
                                <option value="" disabled selected>Select Medicine</option>
                                <?php include 'get_medicine_select.php'; ?>
                            </select>
                        </div>

                        <!-- Medicine Quantity -->
                        <div class="mb-3">
                            <label for="quantity" class="form-label">Quantity:</label>
                            <input type="number" class="form-control" id="quantity" name="quantity" placeholder="Enter Quantity" min="1" required>
                        </div>

                        <!-- Recommendation (Initially Disabled) -->
                        <div class="mb-3">
                            <label for="recommendation" class="form-label">Recommendation:</label>
                            <textarea class="form-control" id="recommendation" name="recommendation" placeholder="Explain your recommendation (or N/A if none)" ></textarea>
                        </div>

                        <!-- Schedule -->
                        <div class="mb-3">
                            <label for="schedule" class="form-label">Schedule:</label>
                            <input type="datetime-local" class="form-control" id="schedule" name="schedule" required>
                        </div>

                        <!-- Submit Button -->
                        <div class="mb-3">
                            <button type="submit" class="btn btn-primary">Save</button>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="reset" form="consultationForm" class="btn btn-info">Reset</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
        
    <main>
        <!-- Button to open the Consultation Modal -->
        <div class="container bg-light d-flex ">
            <button id="delete-selected" class="btn btn-danger mx-5">Delete Selected</button> 
            <button type="button" class="btn btn-success me-2" data-bs-toggle="modal" data-bs-target="#addConsultationModal">Click to add consultation</button>
            <button id="export-excel" class="btn btn-success me-2">Download As Excel</button>
            <button id="export-pdf" class="btn btn-success me-2">Download As PDF</button>
        </div>
        <?php
        require 'db_conn.php';

        if (!$conn) {
            echo "Connection failed!";
            exit();
        }

        // Query to select data from the table
        $sql = "SELECT * FROM consultations";
        $result = $conn->query($sql);
        ?>
        <!-- Consultation Table -->
        <div class="container table-container">
            <table id="consultationTable" class="display table table-striped table-hover table-bordered" style="width:100%;">
                <thead>
                    <tr>
                        <th>Select</th>
                        <th>Fullname</th>
                        <th>Purpose</th>
                        <th>Reason</th>
                        <th>Type of Illness</th>
                        <th>Disease</th>
                        <th>Medicine Name</th>
                        <th>Quantity</th>
                        <th>Recommendations</th>
                        <th>Schedule</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="tableBody">
                    <!-- Dynamic rows will be populated here -->
                </tbody>
            </table>
        </div>




    <!-- JavaScript Libraries for jQuery, Bootstrap, Select2, and DataTables -->
    <script>
        fetch('get_consultation_and_patient_data.php')
            .then(response => {
                if (!response.ok) {
                    // Handle any HTTP errors like 404 or 500
                    throw new Error(`HTTP error! Status: ${response.status}`);
                }
                return response.json(); // Parse JSON response
            })
            .then(data => {
                console.log(data);  // Log the response to check the data

                const tableBody = document.querySelector('#tableBody');
                tableBody.innerHTML = ''; // Clear any previous table data

                // Check if data is an array and has content
                if (Array.isArray(data) && data.length > 0) {
                    const fragment = document.createDocumentFragment(); // Use DocumentFragment for better performance

                    // Loop through each row in the fetched data and create a table row
                    data.forEach(row => {
                        const tableRow = document.createElement('tr');

                        // Ensure each cell is populated correctly, using the correct field names
                        tableRow.innerHTML = `
                            <td><input type="checkbox" class="row-checkbox" value="${row.consultation_id}"></td>
                            <td>${row.patient_name || 'N/A'}</td>
                            <td>${row.consultation_purpose || 'N/A'}</td>
                            <td>${row.consultation_reason || 'N/A'}</td>
                            <td>${row.type_of_illness || 'N/A'}</td>
                            <td>${row.consultation_disease || 'N/A'}</td>
                            <td>${row.medicine_name || 'N/A'}</td>
                            <td>${row.quantity || 'N/A'}</td>
                            <td>${row.recommendation || 'N/A'}</td> 
                            <td>${row.consultation_schedule || 'N/A'}</td>
                            <td>${row.status || 'N/A'}</td>
                            <td>
                                <div class="d-flex justify-content-between">
                                    <!-- Link that redirects to the edit page with the consultation_id -->
                                    <a href="editconsultation.php?id=${row.consultation_id}" class="btn btn-success btn-sm me-2">
                                        Edit
                                    </a>
                                </div>
                            </td>

                        `;
                        // Append this row to the document fragment
                        fragment.appendChild(tableRow);
                    });

                    // After the loop, append the fragment to the tableBody all at once
                    tableBody.appendChild(fragment);
                } else {
                    // If no records are found, show a message in the table
                    tableBody.innerHTML = '<tr><td colspan="12">No records found.</td></tr>';
                }
            })
            .catch(error => {
                console.error('Error fetching data:', error);
                const tableBody = document.querySelector('#tableBody');
                // If there's an error, display an error message in the table
                tableBody.innerHTML = '<tr><td colspan="12">Error fetching data. Please try again later.</td></tr>';
            });

$(document).ready(function () {
    // Initialize DataTable once and define settings
    let table = $('#consultationTable').DataTable({
        "paging": true,
        "pageLength": 4,
        "searching": true,
        "ordering": true,
        "responsive": true,
        "lengthMenu": [2, 4,],
        "language": {
            "search": "Search:",
            "lengthMenu": "Show _MENU_ entries",
            "info": "Showing _START_ to _END_ of _TOTAL_ records",
            "paginate": {
                "next": "Next",
                "previous": "Previous"
            }
        }
    });

    // Fetch data dynamically and populate the DataTable
    fetch('get_consultation_and_patient_data.php')
        .then(response => {
            if (!response.ok) throw new Error('Network response error.');
            return response.json();
        })
        .then(data => {
            table.clear(); // Clear existing rows in the table

            if (Array.isArray(data)) {
                // Add rows dynamically
                data.forEach(row => {
                    table.row.add([
                        `<input type="checkbox" class="row-checkbox" value="${row.consultation_id}">`,
                        row.patient_name || 'N/A',
                        row.consultation_purpose || 'N/A',
                        row.consultation_reason || 'N/A',
                        row.type_of_illness || 'N/A',
                        row.consultation_disease || 'N/A',
                        row.medicine_name || 'N/A',
                        row.quantity || 'N/A',
                        row.recommendation || 'N/A',
                        row.consultation_schedule || 'N/A',
                        row.status || 'N/A',
                        `<a href="editconsultation.php?id=${row.consultation_id}" class="btn btn-success btn-sm me-2">Edit</a>`
                    ]);
                });
            }
            table.draw(); // Redraw the table with new data
        })
        .catch(error => {
            console.error('Error fetching data:', error);
        });

    // Delete selected rows
    $('#delete-selected').click(function () {
        const selectedIds = $('.row-checkbox:checked').map(function () {
            return $(this).val();
        }).get();

        if (selectedIds.length > 0) {
            Swal.fire({
                title: 'Are you sure?',
                text: "You are about to delete the selected records.",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes, delete!',
                cancelButtonText: 'No, cancel!'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: 'deleteconsultation.php',
                        method: 'POST',
                        data: { ids: selectedIds },
                        success: function (response) {
                            Swal.fire('Deleted!', response.message, 'success');
                            table.rows('.row-checkbox:checked').remove().draw(); // Remove rows and redraw
                        },
                        error: function () {
                            Swal.fire('Error!', 'An error occurred while deleting.', 'error');
                        }
                    });
                }
            });
        } else {
            Swal.fire('Warning!', 'No records selected for deletion.', 'warning');
        }
    });
});


// Function to enable edit mode and populate the modal with data
function enableEditMode(data) {
    // Set the modal title for edit mode
    document.getElementById('addConsultationModalLabel').textContent = "Edit a Consultation";

    // Enable the recommendation field
    document.getElementById('recommendation').disabled = false;

    // Fill the form fields with existing consultation data
    document.getElementById('healthcare_id').value = data.healthcare_id;
    document.getElementById('patient_id').value = data.patient_id;
    document.getElementById('medicine_id').value = data.medicine_id;
    document.getElementById('quantity').value = data.quantity;
    document.getElementById('recommendation').value = data.recommendation;
    document.getElementById('schedule').value = data.schedule;

    // Optionally open the modal
    const modal = new bootstrap.Modal(document.getElementById('addConsultationModal'));
    modal.show();
}

     $(document).ready(function() {
    // Initialize DataTable
    $('#consultationTable').DataTable();
    
    // Handle "Delete Selected" functionality (BULK DELETE)
    $(document).ready(function () {
            // Initialize DataTable
            $('#consultationTable').DataTable();

            // Handle "Delete Selected" functionality (Bulk Delete)
            $('#delete-selected').click(function () {
                const selectedIds = $('.row-checkbox:checked').map(function () {
                    return $(this).val();
                }).get();

                if (selectedIds.length > 0) {
                    Swal.fire({
                        title: 'Are you sure?',
                        text: "You are about to delete the selected records.",
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonText: 'Yes, delete!',
                        cancelButtonText: 'No, cancel!'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            $.ajax({
                                url: 'deleteconsultation.php',
                                method: 'POST',
                                data: { ids: selectedIds },
                                dataType: 'json',
                                success: function (response) {
                                    if (response.success) {
                                        Swal.fire('Deleted!', response.message, 'success').then(() => {
                                            location.reload();
                                        });
                                    } else {
                                        Swal.fire('Error!', response.message, 'error');
                                    }
                                },
                                error: function () {
                                    Swal.fire('Error!', 'An error occurred while deleting.', 'error');
                                }
                            });
                        }
                    });
                } else {
                    Swal.fire('Warning!', 'No records selected for deletion.', 'warning');
                }
            });
        });
    // SCRIPT FOR UPDATE PATIENT ID IF SELECTED
    document.getElementById('patient_name').addEventListener('change', function() {
        // Get the selected option's data
        var selectedOption = this.options[this.selectedIndex];
        var patientId = selectedOption.getAttribute('data-patient-id'); // assuming each option has a 'data-patient-id' attribute
        
        // Update the Patient ID input field
        document.getElementById('patient_id').value = patientId;
    });

    // Script for logout button with confirmation
    document.addEventListener('DOMContentLoaded', function () {
        const logoutButton = document.querySelector('#signOutBtn');
        if (logoutButton) {
            logoutButton.addEventListener('click', function (e) {
                e.preventDefault(); // Prevent the default link action
                Swal.fire({
                    title: 'Are you sure?',
                    text: "Do you really want to sign out?",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, sign out!',
                    cancelButtonText: 'No, stay logged in'
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.location.href = 'logout.php'; // Adjust the URL to your logout script
                    }
                });
            });
        } else {
            console.error("Logout button (signOutBtn) not found!");
        }
    });

    // Script for downloading as Excel and PDF
    $('#export-excel').click(function() {
        const table = document.getElementById('consultationTable');
        const workbook = XLSX.utils.table_to_book(table, { sheet: "Sheet1" });
        XLSX.writeFile(workbook, 'Consultation_Data.xlsx');
    });

    $('#export-pdf').click(function() {
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();
        doc.autoTable({
            html: '#consultationTable',
        });
        doc.save('Consultation_Data.pdf');
    });
});
// Add event listener to the patient select dropdown
    document.getElementById('patient_name').addEventListener('change', function() {
        // Get the selected option
        var selectedOption = this.options[this.selectedIndex];

        // Extract the data-patient-id attribute
        var patientId = selectedOption.getAttribute('data-patient-id');

        // Set the value of the patient ID input field
        document.getElementById('patient_id').value = patientId;
    });

// Function to fetch staff details and update the staff name field
function updatePatientDetails() {
    var healthcare_id = document.getElementById('healthcare_id').value;

    if (healthcare_id) {
        var xhr = new XMLHttpRequest();
        xhr.open('GET', 'get_healthcare_staff.php?healthcare_id=' + healthcare_id, true);
        xhr.onload = function() {
            if (xhr.status === 200) {
                var response = JSON.parse(xhr.responseText);
                if (response.success && response.healthcarestaff_name) {
                    document.getElementById('healthcarestaff_name').value = response.healthcarestaff_name;
                } else {
                    alert('Patient not found.');
                }
            } else {
                alert('Error fetching patient details.');
            }
        };
        xhr.send();
    } else {
        document.getElementById('healthcarestaff_name').value = ''; 
    }
}
$(document).ready(function () {
    // When the form is submitted
    $("#consultationForm").submit(function () {
        // Log the form data to check if everything is being passed
        console.log("Form Data: ", $(this).serialize());

        // No need for e.preventDefault() here
        // Allow the form to submit naturally to the 'action' attribute
    });
});

      

    </script>

</body>
</html>