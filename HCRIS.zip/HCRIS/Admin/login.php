<?php
session_start();
include "db_conn.php";

if (isset($_POST['uname']) && isset($_POST['password'])) {
    function validate($data) {
        return htmlspecialchars(stripslashes(trim($data)));
    }

    // Sanitize inputs
    $uname = validate($_POST['uname']);
    $pass = validate($_POST['password']);

    // Check for empty fields
    if (empty($uname) || empty($pass)) {
        header("Location: Index.php?error=All fields are required");
        exit();
    } else {
        // Check credentials in the database
        $sql = "SELECT * FROM admin_register WHERE username = ? AND password = ?";
        $stmt = $conn->prepare($sql);

        if (!$stmt) {
            die("SQL Error: " . $conn->error); // Debugging: Display SQL error if prepare fails
        }

        $stmt->bind_param("ss", $uname, $pass); // Using plain passwords as per your requirement
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            // Fetch user data
            $row = $result->fetch_assoc();
            $_SESSION['admin_name'] = $row['name'];
            $_SESSION['admin_id'] = $row['admin_id'];

            // Log the login session
            $adminName = $row['name'];
            $adminId = $row['admin_id'];

            $insertLogin = "INSERT INTO admin_loginsessions (admin_name, admin_id, login_time) VALUES (?, ?, NOW())";
            $loginStmt = $conn->prepare($insertLogin);

            if ($loginStmt) {
                $loginStmt->bind_param("ss", $adminName, $adminId);
                $loginStmt->execute();
            }

            // Redirect to admin homepage on successful login
            header("Location: adminhomepage.php");
            exit();
        } else {
            // Invalid credentials
            header("Location: Index.php?error=Invalid username or password");
            exit();
        }
    }
} else {
    // Redirect to login page if accessed without POST data
    header("Location: Index.php");
    exit();
}
?>
