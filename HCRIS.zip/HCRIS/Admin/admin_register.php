<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Registration</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <h3 class="text-center">Admin Registration</h3>
                <!-- Display error or success messages -->
                <?php if (isset($_GET['error'])): ?>
                    <div class="alert alert-danger" role="alert">
                        <?php echo htmlspecialchars($_GET['error']); ?>
                    </div>
                <?php endif; ?>
                <?php if (isset($_GET['success'])): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo htmlspecialchars($_GET['success']); ?>
                    </div>
                <?php endif; ?>

                <!-- Registration Form -->
                <form action="adminregister_process.php" method="post">
                    <!-- Admin ID -->
                    <div class="mb-3">
                        <label for="admin_id" class="form-label">Admin ID</label>
                        <input type="text" name="admin_id" id="admin_id" class="form-control" placeholder="Enter Admin ID" required>
                    </div>
                    <!-- Full Name -->
                    <div class="mb-3">
                        <label for="name" class="form-label">Full Name</label>
                        <input type="text" name="name" id="name" class="form-control" placeholder="Enter your full name" required>
                    </div>
                    <!-- Username -->
                    <div class="mb-3">
                        <label for="uname" class="form-label">Username</label>
                        <input type="text" name="uname" id="uname" class="form-control" placeholder="Enter your username" required>
                    </div>
                    <!-- Password -->
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" name="password" id="password" class="form-control" placeholder="Enter your password" required>
                    </div>
                    <!-- Confirm Password -->
                    <div class="mb-3">
                        <label for="confirm_password" class="form-label">Confirm Password</label>
                        <input type="password" name="confirm_password" id="confirm_password" class="form-control" placeholder="Confirm your password" required>
                    </div>
                    <!-- Submit Button -->
                    <div class="mb-3 text-center">
                        <button type="submit" class="btn btn-primary">Register</button>
                    </div>
                    <!-- Link to Login -->
                    <div class="text-center">
                        <p>Already have an account? <a href="adminhomepage.php">click to go back</a>.</p>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Bootstrap JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
