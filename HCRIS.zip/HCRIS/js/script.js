// Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyAKVpIaAXCD1GH1WpHDXGCCzzDgHK8VIeg",
    authDomain: "sms-otp-verification-42cba.firebaseapp.com",
    projectId: "sms-otp-verification-42cba",
    storageBucket: "sms-otp-verification-42cba.firebasestorage.app",
    messagingSenderId: "192331130455",
    appId: "1:192331130455:web:b1b90789564c3468ca2512",
    measurementId: "G-9ZZK56WS9B"
  };
// Initialize Firebase
const app = firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();

// Function to render invisible reCAPTCHA
function render() {
    window.recaptchaVerifier = new firebase.auth.RecaptchaVerifier('recaptcha-container', {
        size: 'invisible',  // Invisible reCAPTCHA
        callback: function(response) {
            // reCAPTCHA solved, you can send OTP now
            sendOTP();
        }
    });
    recaptchaVerifier.render();
}

// Function to show the modal
function openModal() {
    document.getElementById("otpModal").style.display = "block";
}

// Function to close the modal
function closeModal() {
    document.getElementById("otpModal").style.display = "none";
}

// Automatically move focus to next OTP input box
function moveFocus(current, next) {
    if (current.value.length == current.maxLength) {
        next.focus();
    }
}

// Function to send OTP (triggered on button click)
function sendOTP() {
    var number = document.getElementById('number').value;

    // Send OTP using Firebase Authentication
    const phoneNumber = number;
    const appVerifier = window.recaptchaVerifier;  // Invisible reCAPTCHA verifier

    auth.signInWithPhoneNumber(phoneNumber, appVerifier)
        .then(function(confirmationResult) {
            // The confirmationResult object is used to verify the OTP
            window.confirmationResult = confirmationResult;
            document.querySelector('.number-input').style.display = 'none';
            openModal();
        })
        .catch(function(error) {
            alert("Error during sending OTP: " + error.message);
        });
}

// Function to verify OTP
function verifyCode() {
    var otp = "";
    for (let i = 1; i <= 6; i++) {
        otp += document.getElementById('otp' + i).value;
    }

    // Verify the OTP entered by the user
    window.confirmationResult.confirm(otp)
        .then(function() {
            document.querySelector('.result').style.display = '';
            document.querySelector('.correct').style.display = '';
            console.log('OTP Verified');
        })
        .catch(function() {
            document.querySelector('.result').style.display = '';
            document.querySelector('.incorrect').style.display = '';
            console.log('OTP Not correct');
        });
}

// Initialize invisible reCAPTCHA on page load
render();
