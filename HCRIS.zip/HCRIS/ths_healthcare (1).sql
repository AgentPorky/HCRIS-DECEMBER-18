-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 18, 2024 at 07:11 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ths_healthcare`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminlogoutsessions`
--

CREATE TABLE `adminlogoutsessions` (
  `logout_id` int(11) NOT NULL,
  `admin_id` varchar(100) NOT NULL,
  `admin_name` varchar(100) NOT NULL,
  `logout_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adminlogoutsessions`
--

INSERT INTO `adminlogoutsessions` (`logout_id`, `admin_id`, `admin_name`, `logout_time`) VALUES
(1, '', 'PORTGAS D. ACE', '2024-12-18 11:37:31'),
(2, '21-1111', 'CHOPPER CHOPPER', '2024-12-18 11:41:49');

-- --------------------------------------------------------

--
-- Table structure for table `admin_healthcare_unit`
--

CREATE TABLE `admin_healthcare_unit` (
  `healthcare_id` varchar(255) NOT NULL,
  `healthcarestaff_name` varchar(50) NOT NULL,
  `position_of_staff` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='ADMIN''S POSITION IN HEALTHCARE';

--
-- Dumping data for table `admin_healthcare_unit`
--

INSERT INTO `admin_healthcare_unit` (`healthcare_id`, `healthcarestaff_name`, `position_of_staff`, `address`) VALUES
('21-0916', 'GUILLER JAMES C MANTALA', 'ADMIN', 'BONBON CATARMAN CAMIGUIN');

-- --------------------------------------------------------

--
-- Table structure for table `admin_loginsessions`
--

CREATE TABLE `admin_loginsessions` (
  `log_id` int(11) NOT NULL,
  `admin_name` varchar(255) NOT NULL,
  `admin_id` varchar(50) NOT NULL,
  `login_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `action_type` enum('login','logout') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_loginsessions`
--

INSERT INTO `admin_loginsessions` (`log_id`, `admin_name`, `admin_id`, `login_time`, `action_type`) VALUES
(1, 'PORTGAS D. ACE', '', '2024-12-18 11:33:29', 'login'),
(2, 'CHOPPER CHOPPER', '21-1111', '2024-12-18 11:37:41', 'login'),
(3, 'ADMIN', '22-2222', '2024-12-18 11:42:14', 'login');

-- --------------------------------------------------------

--
-- Table structure for table `admin_medicine_inventory`
--

CREATE TABLE `admin_medicine_inventory` (
  `medicine_id` varchar(50) NOT NULL,
  `medicine_name` varchar(50) NOT NULL,
  `medicine_quantity` varchar(50) NOT NULL,
  `date_manufactured` varchar(50) NOT NULL,
  `expiration_date` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='DATABASE OF MEDICINE''S AVAILABILITY';

--
-- Dumping data for table `admin_medicine_inventory`
--

INSERT INTO `admin_medicine_inventory` (`medicine_id`, `medicine_name`, `medicine_quantity`, `date_manufactured`, `expiration_date`) VALUES
('Paracetamol Stock 2', 'PARACETAMOL', '50', '2024-12-15', '2024-12-15');

-- --------------------------------------------------------

--
-- Table structure for table `admin_register`
--

CREATE TABLE `admin_register` (
  `admin_id` varchar(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_register`
--

INSERT INTO `admin_register` (`admin_id`, `username`, `password`, `name`) VALUES
('', 'PORTGAS', 'PORTGAS', 'PORTGAS D. ACE'),
('21-1111', 'CHOPPER', 'CHOPPER', 'CHOPPER CHOPPER'),
('21-9999', 'LUFFY', 'LUFFY', 'MONKEY D. LUFFY'),
('22-2222', 'ADMIN', 'ADMIN', 'ADMIN');

-- --------------------------------------------------------

--
-- Table structure for table `consultations`
--

CREATE TABLE `consultations` (
  `consultation_id` int(255) NOT NULL,
  `healthcare_id` varchar(255) NOT NULL,
  `patient_id` varchar(255) NOT NULL,
  `patient_name` varchar(255) NOT NULL,
  `purpose` varchar(255) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `type_of_illness` varchar(255) NOT NULL,
  `disease` varchar(255) NOT NULL,
  `medicine_name` varchar(255) NOT NULL,
  `quantity` varchar(255) NOT NULL,
  `recommendation` varchar(255) NOT NULL,
  `schedule` datetime NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `consultations`
--

INSERT INTO `consultations` (`consultation_id`, `healthcare_id`, `patient_id`, `patient_name`, `purpose`, `reason`, `type_of_illness`, `disease`, `medicine_name`, `quantity`, `recommendation`, `schedule`, `status`) VALUES
(2, '21-0916', '2134', 'Jessrhon C. Toyhoroda', 'CONSULT', 'qwerty', 'FEVER', 'N/A', 'PARACETAMOL', '100', '12345', '2024-12-18 04:11:00', 'Active'),
(3, '21-0916', '2134', 'Jessrhon C. Toyhoroda', 'CONSULT', 'qwerty', 'FEVER', 'N/A', 'PARACETAMOL', '100', '12345', '2024-12-18 04:11:00', 'Active'),
(5, '21-0916', '2134', 'Jessrhon C. Toyhoroda', 'CONSULT', 'qwerty', 'FEVER', 'N/A', 'PARACETAMOL', '100', '12345', '2024-12-18 04:11:00', 'Active'),
(6, '21-0916', '2134', 'Jessrhon C. Toyhoroda', 'CONSULT', 'qwerty', 'FEVER', 'N/A', 'PARACETAMOL', '100', '12345', '2024-12-18 04:11:00', 'Active'),
(7, '21-0916', '2134', 'Jessrhon C. Toyhoroda', 'CONSULT', 'qwerty', 'FEVER', 'N/A', 'PARACETAMOL', '100', '12345', '2024-12-18 04:11:00', 'Active'),
(8, '21-0916', '5', 'Jessrhon C. Toyhoroda', 'CONSULT', 'qwerty', 'FEVER', 'N/A', 'PARACETAMOL', '200', '234', '2024-12-18 04:28:00', 'Active'),
(9, '21-0916', '5', 'Jessrhon C. Toyhoroda', 'CONSULT', 'qwerty', 'FEVER', 'N/A', 'PARACETAMOL', '200', '234', '2024-12-18 04:28:00', 'Active'),
(10, '21-0916', '5', 'Jessrhon C. Toyhoroda', 'CONSULT', 'qwerty', 'FEVER', 'N/A', 'PARACETAMOL', '100', '1234', '2024-12-18 04:38:00', 'Active'),
(11, '21-0916', '5', 'Jessrhon C. Toyhoroda', 'CONSULT', 'qwerty', 'FEVER', 'N/A', 'PARACETAMOL', '100', '1234', '2024-12-18 04:38:00', 'Active'),
(12, '21-0916', '5', 'Jessrhon C. Toyhoroda', 'CONSULT', 'qwerty', 'FEVER', 'N/A', 'PARACETAMOL', '100', '1234', '2024-12-18 04:38:00', 'Active'),
(13, '21-0916', '5', 'Jessrhon C. Toyhoroda', 'CONSULT', 'qwerty', 'FEVER', 'N/A', 'PARACETAMOL', '100', '1234', '2024-12-18 04:38:00', 'Active'),
(14, '21-0916', '5', 'Jessrhon C. Toyhoroda', 'CONSULT', 'qwerty', 'FEVER', 'N/A', 'PARACETAMOL', '100', '1234', '2024-12-18 04:38:00', 'Active'),
(15, '21-0916', '5', 'Jessrhon C. Toyhoroda', 'CONSULT', 'qwerty', 'FEVER', 'N/A', 'PARACETAMOL', '100', '1234', '2024-12-18 04:38:00', 'Active'),
(16, '21-0916', '5', 'Jessrhon C. Toyhoroda', 'CONSULT', 'qwerty', 'FEVER', 'N/A', 'PARACETAMOL', '100', '1234', '2024-12-18 04:38:00', 'Active'),
(17, '21-0916', '5', 'Jessrhon C. Toyhoroda', 'CONSULT', 'qwerty', 'FEVER', 'N/A', 'PARACETAMOL', '100', '1234', '2024-12-18 04:38:00', 'Active'),
(18, '21-0916', '5', 'Jessrhon C. Toyhoroda', 'CONSULT', 'qwerty', 'n/a', 'n/a', 'PARACETAMOL', '200', '12345', '2024-12-18 04:40:00', 'Active'),
(19, '21-0916', '5', 'Jessrhon C. Toyhoroda', 'CONSULT', 'qwerty', 'n/a', 'n/a', 'PARACETAMOL', '200', '12345', '2024-12-18 04:40:00', 'Active'),
(20, '21-0916', '5', 'Jessrhon C. Toyhoroda', 'CONSULT', 'STOMACH ACHE', 'FEVER', 'fiver', 'PARACETAMOL', '50', '122', '2024-12-18 04:57:00', 'Active'),
(21, '21-0916', '5', 'Jessrhon C. Toyhoroda', 'CONSULT', 'STOMACH ACHE', 'FEVER', 'fiver', 'PARACETAMOL', '50', '122', '2024-12-18 04:57:00', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE `patients` (
  `patient_id` int(11) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `birthday` varchar(255) NOT NULL,
  `age` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `Social_stat` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `otps` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`patient_id`, `fullname`, `birthday`, `age`, `address`, `Social_stat`, `gender`, `username`, `password`, `otps`) VALUES
(5, 'Jessrhon C. Toyhoroda', '2024-12-13', '22', 'OMYCCO', 'single', 'male', '123456', '$2y$10$xRvm2bphKx4DT52DodGyce0S3GD5GVDYJEQ.slqXNulktFz9eIG7S', '');

-- --------------------------------------------------------

--
-- Table structure for table `patients_appointment`
--

CREATE TABLE `patients_appointment` (
  `appointment_id` int(255) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `patient_name` varchar(255) NOT NULL,
  `schedule` datetime NOT NULL,
  `purpose` varchar(255) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `t_o_i` varchar(255) NOT NULL,
  `disease` varchar(255) NOT NULL,
  `medicine_id` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patients_appointment`
--

INSERT INTO `patients_appointment` (`appointment_id`, `patient_id`, `patient_name`, `schedule`, `purpose`, `reason`, `t_o_i`, `disease`, `medicine_id`) VALUES
(1, 5, 'Jessrhon C. Toyhorada', '2024-12-18 00:00:00', 'pa consult', ' kay labad ang ulo', 'fever', 'n/a', '0');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adminlogoutsessions`
--
ALTER TABLE `adminlogoutsessions`
  ADD PRIMARY KEY (`logout_id`);

--
-- Indexes for table `admin_healthcare_unit`
--
ALTER TABLE `admin_healthcare_unit`
  ADD PRIMARY KEY (`healthcare_id`);

--
-- Indexes for table `admin_loginsessions`
--
ALTER TABLE `admin_loginsessions`
  ADD PRIMARY KEY (`log_id`);

--
-- Indexes for table `admin_register`
--
ALTER TABLE `admin_register`
  ADD UNIQUE KEY `admin_id` (`admin_id`);

--
-- Indexes for table `consultations`
--
ALTER TABLE `consultations`
  ADD PRIMARY KEY (`consultation_id`);

--
-- Indexes for table `patients`
--
ALTER TABLE `patients`
  ADD PRIMARY KEY (`patient_id`);

--
-- Indexes for table `patients_appointment`
--
ALTER TABLE `patients_appointment`
  ADD PRIMARY KEY (`appointment_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adminlogoutsessions`
--
ALTER TABLE `adminlogoutsessions`
  MODIFY `logout_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `admin_loginsessions`
--
ALTER TABLE `admin_loginsessions`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `consultations`
--
ALTER TABLE `consultations`
  MODIFY `consultation_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `patients`
--
ALTER TABLE `patients`
  MODIFY `patient_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `patients_appointment`
--
ALTER TABLE `patients_appointment`
  MODIFY `appointment_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
